#include "main.h"

void main(void){
    
    sys_uart_init();
    printf("Hello, World!\n");

}